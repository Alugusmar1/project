export interface Employee {
    employeeId: number,
    employeeName: string,
    employeeContactNumber: string,
    employeeAddress: string,
    employeeGender: string,
    employeeDepartment: string,
    employeeSkills: string
}